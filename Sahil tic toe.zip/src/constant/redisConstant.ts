const REDIS = {
    OPTION: {
        host: process.env.REDIS_HOST,
        port: process.env.REDIS_PORT,
    }
}

export { REDIS }