import Queue from "bull"
import { logger } from "../../logger";
import { redisOption } from "../../connection/redisConnection";
import { checkTurn } from "../../playing/checkTurn";
import { QUEUE_EVENT } from "../../constant/queueConstant";
import { log } from "winston";

const roundTimer = async (data: any) => {
    try {
        console.log("This is At After RoundTimer ::::::::", data)
        const tableId: any = data.tableId
        let roundTimerQueue = new Queue(QUEUE_EVENT.ROUND_TIMER, redisOption);
        let options = {
            jobId: tableId.toString(),
            delay: data.time,
            attempts: 1
        }
        roundTimerQueue.add(data, options)
        console.log(`roundTimerQueue`,roundTimerQueue );
        roundTimerQueue.process(async (data: any) => {
            console.log("This is in Process ::::::::::::::", data.data)
            data = {
                tableId: data.data.tableId.toString(),
            }
            await setTimeout(() => {
                checkTurn(data)
            }, 1000)
        })
    } catch (error) {
        console.log("Queue RoundTimer Error :::", error)
        logger.error("Queue RoundTimer Error :::", error)
    }
}

export { roundTimer }